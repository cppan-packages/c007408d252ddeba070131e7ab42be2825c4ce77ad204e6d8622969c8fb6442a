//
// HTTPServerResponse.cpp
//
// Library: Net
// Package: HTTPServer
// Module:  HTTPServerResponse
//
// Copyright (c) 2005-2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/Net/HTTPServerResponse.h"


namespace Poco {
namespace Net {


HTTPServerResponse::HTTPServerResponse()
{
}


HTTPServerResponse::~HTTPServerResponse()
{
}


} } // namespace Poco::Net
